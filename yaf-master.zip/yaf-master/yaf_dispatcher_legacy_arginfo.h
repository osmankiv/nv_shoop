/* This is a generated file, edit the .stub.php file instead.
 * Stub hash: c0fe3d13422654adb5be158a281a4a16d861f00d */

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_Yaf_Dispatcher___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

#define arginfo_class_Yaf_Dispatcher_enableView arginfo_class_Yaf_Dispatcher___construct

#define arginfo_class_Yaf_Dispatcher_disableView arginfo_class_Yaf_Dispatcher___construct

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_Yaf_Dispatcher_initView, 0, 0, 1)
	ZEND_ARG_INFO(0, templates_dir)
	ZEND_ARG_INFO(0, options)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_Yaf_Dispatcher_setView, 0, 0, 1)
	ZEND_ARG_INFO(0, view)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_Yaf_Dispatcher_setRequest, 0, 0, 1)
	ZEND_ARG_INFO(0, request)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_Yaf_Dispatcher_setResponse, 0, 0, 1)
	ZEND_ARG_INFO(0, response)
ZEND_END_ARG_INFO()

#define arginfo_class_Yaf_Dispatcher_getApplication arginfo_class_Yaf_Dispatcher___construct

#define arginfo_class_Yaf_Dispatcher_getRouter arginfo_class_Yaf_Dispatcher___construct

#define arginfo_class_Yaf_Dispatcher_getRequest arginfo_class_Yaf_Dispatcher___construct

#define arginfo_class_Yaf_Dispatcher_getResponse arginfo_class_Yaf_Dispatcher___construct

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_Yaf_Dispatcher_setErrorHandler, 0, 0, 1)
	ZEND_ARG_INFO(0, callback)
	ZEND_ARG_INFO(0, error_types)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_Yaf_Dispatcher_setDefaultModule, 0, 0, 1)
	ZEND_ARG_INFO(0, module)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_Yaf_Dispatcher_setDefaultController, 0, 0, 1)
	ZEND_ARG_INFO(0, controller)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_Yaf_Dispatcher_setDefaultAction, 0, 0, 1)
	ZEND_ARG_INFO(0, action)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_Yaf_Dispatcher_returnResponse, 0, 0, 0)
	ZEND_ARG_INFO(0, flag)
ZEND_END_ARG_INFO()

#define arginfo_class_Yaf_Dispatcher_autoRender arginfo_class_Yaf_Dispatcher_returnResponse

#define arginfo_class_Yaf_Dispatcher_flushInstantly arginfo_class_Yaf_Dispatcher_returnResponse

#define arginfo_class_Yaf_Dispatcher_dispatch arginfo_class_Yaf_Dispatcher_setRequest

#define arginfo_class_Yaf_Dispatcher_throwException arginfo_class_Yaf_Dispatcher_returnResponse

#define arginfo_class_Yaf_Dispatcher_catchException arginfo_class_Yaf_Dispatcher_returnResponse

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_Yaf_Dispatcher_registerPlugin, 0, 0, 1)
	ZEND_ARG_INFO(0, plugin)
ZEND_END_ARG_INFO()

#define arginfo_class_Yaf_Dispatcher_getDefaultModule arginfo_class_Yaf_Dispatcher___construct

#define arginfo_class_Yaf_Dispatcher_getDefaultController arginfo_class_Yaf_Dispatcher___construct

#define arginfo_class_Yaf_Dispatcher_getDefaultAction arginfo_class_Yaf_Dispatcher___construct

#define arginfo_class_Yaf_Dispatcher_getInstance arginfo_class_Yaf_Dispatcher___construct
