/* This is a generated file, edit the .stub.php file instead.
 * Stub hash: c1419f58751475cec2cf84b0bab3d759846eea79 */

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_Yaf_Application___construct, 0, 0, 1)
	ZEND_ARG_INFO(0, config)
	ZEND_ARG_INFO(0, environ)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_Yaf_Application_run, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_Yaf_Application_execute, 0, 0, 1)
	ZEND_ARG_INFO(0, callback)
ZEND_END_ARG_INFO()

#define arginfo_class_Yaf_Application_environ arginfo_class_Yaf_Application_run

#define arginfo_class_Yaf_Application_bootstrap arginfo_class_Yaf_Application_run

#define arginfo_class_Yaf_Application_getConfig arginfo_class_Yaf_Application_run

#define arginfo_class_Yaf_Application_getModules arginfo_class_Yaf_Application_run

#define arginfo_class_Yaf_Application_getDispatcher arginfo_class_Yaf_Application_run

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_Yaf_Application_setAppDirectory, 0, 0, 1)
	ZEND_ARG_INFO(0, directory)
ZEND_END_ARG_INFO()

#define arginfo_class_Yaf_Application_getAppDirectory arginfo_class_Yaf_Application_run

#define arginfo_class_Yaf_Application_getLastErrorNo arginfo_class_Yaf_Application_run

#define arginfo_class_Yaf_Application_getLastErrorMsg arginfo_class_Yaf_Application_run

#define arginfo_class_Yaf_Application_clearLastError arginfo_class_Yaf_Application_run

#define arginfo_class_Yaf_Application_app arginfo_class_Yaf_Application_run
