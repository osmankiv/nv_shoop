/* This is a generated file, edit the .stub.php file instead.
 * Stub hash: ead31c0ce44b07f287533a18ab963e9a64b12bab */

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_Yaf_Registry___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_Yaf_Registry_get, 0, 0, 1)
	ZEND_ARG_INFO(0, name)
ZEND_END_ARG_INFO()

#define arginfo_class_Yaf_Registry_has arginfo_class_Yaf_Registry_get

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_Yaf_Registry_set, 0, 0, 2)
	ZEND_ARG_INFO(0, name)
	ZEND_ARG_INFO(0, value)
ZEND_END_ARG_INFO()

#define arginfo_class_Yaf_Registry_del arginfo_class_Yaf_Registry_get
