/* This is a generated file, edit the .stub.php file instead.
 * Stub hash: 6d9544072e642f53747bc52f01c4a4a52aa0e3e5 */

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_Yaf_Response_Abstract___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_Yaf_Response_Abstract_setBody, 0, 0, 1)
	ZEND_ARG_INFO(0, body)
	ZEND_ARG_INFO(0, name)
ZEND_END_ARG_INFO()

#define arginfo_class_Yaf_Response_Abstract_appendBody arginfo_class_Yaf_Response_Abstract_setBody

#define arginfo_class_Yaf_Response_Abstract_prependBody arginfo_class_Yaf_Response_Abstract_setBody

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_Yaf_Response_Abstract_clearBody, 0, 0, 0)
	ZEND_ARG_INFO(0, name)
ZEND_END_ARG_INFO()

#define arginfo_class_Yaf_Response_Abstract_getBody arginfo_class_Yaf_Response_Abstract_clearBody

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_Yaf_Response_Abstract_setRedirect, 0, 0, 1)
	ZEND_ARG_INFO(0, url)
ZEND_END_ARG_INFO()

#define arginfo_class_Yaf_Response_Abstract_response arginfo_class_Yaf_Response_Abstract___construct

#define arginfo_class_Yaf_Response_Abstract___toString arginfo_class_Yaf_Response_Abstract___construct

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_Yaf_Response_Http_setHeader, 0, 0, 2)
	ZEND_ARG_INFO(0, name)
	ZEND_ARG_INFO(0, value)
	ZEND_ARG_INFO(0, replace)
	ZEND_ARG_INFO(0, response_code)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_Yaf_Response_Http_setAllHeaders, 0, 0, 1)
	ZEND_ARG_INFO(0, headers)
ZEND_END_ARG_INFO()

#define arginfo_class_Yaf_Response_Http_getHeader arginfo_class_Yaf_Response_Abstract_clearBody

#define arginfo_class_Yaf_Response_Http_clearHeaders arginfo_class_Yaf_Response_Abstract___construct

#define arginfo_class_Yaf_Response_Http_setRedirect arginfo_class_Yaf_Response_Abstract_setRedirect

#define arginfo_class_Yaf_Response_Http_response arginfo_class_Yaf_Response_Abstract___construct
