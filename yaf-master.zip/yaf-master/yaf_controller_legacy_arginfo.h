/* This is a generated file, edit the .stub.php file instead.
 * Stub hash: c265ad91ca592d72f56f0603c262bcb90f0a1737 */

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_Yaf_Controller_Abstract___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

#define arginfo_class_Yaf_Controller_Abstract_getRequest arginfo_class_Yaf_Controller_Abstract___construct

#define arginfo_class_Yaf_Controller_Abstract_getResponse arginfo_class_Yaf_Controller_Abstract___construct

#define arginfo_class_Yaf_Controller_Abstract_getModuleName arginfo_class_Yaf_Controller_Abstract___construct

#define arginfo_class_Yaf_Controller_Abstract_getView arginfo_class_Yaf_Controller_Abstract___construct

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_Yaf_Controller_Abstract_initView, 0, 0, 0)
	ZEND_ARG_INFO(0, options)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_Yaf_Controller_Abstract_setViewpath, 0, 0, 1)
	ZEND_ARG_INFO(0, view_directory)
ZEND_END_ARG_INFO()

#define arginfo_class_Yaf_Controller_Abstract_getViewpath arginfo_class_Yaf_Controller_Abstract___construct

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_Yaf_Controller_Abstract_forward, 0, 0, 1)
	ZEND_ARG_INFO(0, args1)
	ZEND_ARG_INFO(0, args2)
	ZEND_ARG_INFO(0, args3)
	ZEND_ARG_INFO(0, args4)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_Yaf_Controller_Abstract_redirect, 0, 0, 1)
	ZEND_ARG_INFO(0, url)
ZEND_END_ARG_INFO()

#define arginfo_class_Yaf_Controller_Abstract_getInvokeArgs arginfo_class_Yaf_Controller_Abstract___construct

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_Yaf_Controller_Abstract_getInvokeArg, 0, 0, 1)
	ZEND_ARG_INFO(0, name)
ZEND_END_ARG_INFO()

#define arginfo_class_Yaf_Controller_Abstract_getName arginfo_class_Yaf_Controller_Abstract___construct

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_Yaf_Controller_Abstract_render, 0, 0, 1)
	ZEND_ARG_INFO(0, tpl)
	ZEND_ARG_INFO(0, parameters)
ZEND_END_ARG_INFO()

#define arginfo_class_Yaf_Controller_Abstract_display arginfo_class_Yaf_Controller_Abstract_render

#define arginfo_class_Yaf_Action_Abstract_execute arginfo_class_Yaf_Controller_Abstract___construct

#define arginfo_class_Yaf_Action_Abstract_getController arginfo_class_Yaf_Controller_Abstract___construct

#define arginfo_class_Yaf_Action_Abstract_getControllerName arginfo_class_Yaf_Controller_Abstract___construct
